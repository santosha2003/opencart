<?php
// Heading
$_['heading_title']       = 'Комментарии блога';
// Text
$_['column_comment']       = 'Комментарий';
$_['column_post']       = 'Статья';
$_['column_name']       = 'Автора';
$_['column_date']       = 'Дата добавления';
$_['column_status']       = 'Статус';
$_['text_no_result']       = 'Нет комментариев';
$_['text_enable']       = 'Включено';
$_['text_disable']       = 'Отключено';

$_['entry_status']        = 'Статус';



// Error
$_['error_permission']    = 'Внимание! У вас нет разрешения на изменение комментариев к блогам.';
$_['text_success']        = 'Успех: Вы изменили комментарии к блогам.';
